﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using LoginUser.BOL;
using LoginUser.Controllers.Resources;

namespace LoginUser.Mapping
{
  public class MappingProfile : Profile
  {
    public MappingProfile()
    {
      // Domain Models to Api Resource
     // CreateMap<Customer, CustomerResource>();
      CreateMap<User, UserResource>();
      CreateMap<Admin, OwnerResource>();
    //  CreateMap<HallOwner, OwnerResource>();



      // Api Resource to Domain Models
      
      CreateMap<UserResource, User>();
      CreateMap<OwnerResource, Admin>();
      

      
     // CreateMap<CustomerResource, Admin>().ForSourceMember(c => c.Address, opt => opt.Ignore()).ForSourceMember(c => c.AadharNo, opt => opt.Ignore());



    }
  }
}
