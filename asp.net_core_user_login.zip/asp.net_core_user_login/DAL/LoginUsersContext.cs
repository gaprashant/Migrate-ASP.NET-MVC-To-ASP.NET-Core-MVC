﻿using System;
using LoginUser.BOL;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace LoginUser.DAL
{

  public partial class LoginUsersContext : DbContext
  {
    public LoginUsersContext()
    {
    }

    public LoginUsersContext(DbContextOptions<LoginUsersContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Admin> Admins { get; set; }
  
    public virtual DbSet<User> Users { get; set; }


    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
      modelBuilder.Entity<Admin>(entity =>
      {
        entity.HasKey(e => e.Id);



        entity.HasOne(d => d.User)
            .WithOne()
            .HasForeignKey<Admin>(d => d.UserId)
            .HasConstraintName("FK_AdminUserId");
      });


      modelBuilder.Entity<User>(entity =>
      {
        entity.HasKey(e => e.Id);

        entity.Property(e => e.Email).HasMaxLength(50);

        entity.Property(e => e.Name)
            .IsRequired()
            .HasMaxLength(50);

        entity.Property(e => e.MobileNo)
            .IsRequired()
            .HasMaxLength(15);

        entity.Property(e => e.Password)
            .IsRequired()
            .HasMaxLength(50);

        entity.Property(e => e.Role)
            .IsRequired()
            .HasMaxLength(20);

        entity.Property(e => e.UserName)
            .IsRequired()
            .HasMaxLength(50);
      });
    }
  }
}
