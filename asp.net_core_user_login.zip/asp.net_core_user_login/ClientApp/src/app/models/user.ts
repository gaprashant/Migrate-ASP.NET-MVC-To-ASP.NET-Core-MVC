export interface User {
  userId: number;
  userName: string;
  password: string;
  mobileNo: string;
  name: string;
  email: string;
  role: string;
}
