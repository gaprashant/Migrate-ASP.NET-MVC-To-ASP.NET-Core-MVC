import { User } from './user';

export interface Admin {
  adminId: number;

  user: User;
}
